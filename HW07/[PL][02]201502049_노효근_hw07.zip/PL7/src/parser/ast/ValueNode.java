package parser.ast;

public interface ValueNode extends Node {
}
