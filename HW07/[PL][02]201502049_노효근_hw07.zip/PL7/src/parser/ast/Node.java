package parser.ast;

public interface  Node {

}
