package ast;

public interface ValueNode extends Node{
}
