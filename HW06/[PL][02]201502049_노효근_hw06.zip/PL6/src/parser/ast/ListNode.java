package parser.ast;


public class ListNode extends Node{
	public Node value;
	
}
